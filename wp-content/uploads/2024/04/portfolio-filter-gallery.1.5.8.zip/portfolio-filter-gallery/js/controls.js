jQuery(function() {
    //Simple filter controls
    jQuery('.simplefilter li').click(function() {
        jQuery('.simplefilter li').removeClass('active');
        jQuery(this).addClass('active');
    });
    //Multifilter controls
    jQuery('.multifilter li').click(function() {
        jQuery(this).toggleClass('active');
    });
    //Shuffle control
    jQuery('.shuffle-btn').click(function() {
        jQuery('.sort-btn').removeClass('active');
    });
    //Sort controls
    jQuery('.sort-btn').click(function() {
        jQuery('.sort-btn').removeClass('active');
        jQuery(this).addClass('active');
    });
});
